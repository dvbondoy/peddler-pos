(function() {
  'use strict';

  angular.module('blocks.router', [
    
  ]);
})();