(function() {
  'use strict';

  angular.module('app', [
    'ionic',
    'angularMoment',
    'app.core',
    'app.layout',
    'app.settings',
    'app.product',
    'app.sales',
    'app.people'
  ]);
})();